package com.climate.datas.utils.drone;

@FunctionalInterface
public interface DataGenerator {
    double generate();
}