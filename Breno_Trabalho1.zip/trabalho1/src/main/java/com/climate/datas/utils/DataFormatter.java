package com.climate.datas.utils;

@FunctionalInterface
public interface DataFormatter {

    String format(String[] values);
}
